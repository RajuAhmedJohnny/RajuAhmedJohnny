export interface PresetButtonConfig {
  id: string;
  brandName: string;
  weight: string; // e.g., "5kg", "12.5kg"
  price: number;
  displayName: string; // e.g., "Indane - 14.2kg"
}

export interface SaleEntry {
  id: string;
  cylinderDisplayName: string; // Copied from PresetButtonConfig.displayName
  priceAtSale: number;      // Price per cylinder at the time of sale
  quantity: number;
  totalAmount: number;
  saleDate: string;         // ISO date string e.g., "2023-10-27"
  buyerName?: string;
  buyerAddress?: string;
  buyerMobile?: string;
}

export interface SalesReport {
  totalRevenue: number;
  totalCylindersSold: number;
  salesByCylinderType: {
    [cylinderDisplayName: string]: { // Key is now the dynamic cylinderDisplayName
      quantity: number;
      revenue: number;
    }
  };
  periodStartDate?: string; // Optional: For displaying report period
  periodEndDate?: string;   // Optional: For displaying report period
}

export interface ChatMessage {
  id:string;
  text: string;
  sender: 'user' | 'bot';
  timestamp: Date;
}

export type ReminderPeriod = 'daily' | 'weekly' | 'monthly';