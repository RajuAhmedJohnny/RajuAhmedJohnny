import React, { useState, FormEvent, useEffect } from 'react';
import { PresetButtonConfig } from '../types';
import { CogIcon, XMarkIcon } from './Icons';

interface PresetEditModalProps {
  isOpen: boolean;
  onClose: () => void;
  presetToEdit: PresetButtonConfig | null;
  onUpdatePreset: (presetId: string, updatedData: Omit<PresetButtonConfig, 'id' | 'displayName'>) => void;
  isLoading: boolean;
}

const PresetEditModal: React.FC<PresetEditModalProps> = ({ 
  isOpen, 
  onClose, 
  presetToEdit, 
  onUpdatePreset, 
  isLoading 
}) => {
  const [brandName, setBrandName] = useState<string>('');
  const [weight, setWeight] = useState<string>('');
  const [price, setPrice] = useState<string>('');

  useEffect(() => {
    if (presetToEdit) {
      setBrandName(presetToEdit.brandName);
      setWeight(presetToEdit.weight);
      setPrice(presetToEdit.price.toString());
    } else {
      setBrandName('');
      setWeight('');
      setPrice('');
    }
  }, [presetToEdit, isOpen]);

  if (!isOpen || !presetToEdit) return null;

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    const parsedPrice = parseFloat(price);
    if (!brandName.trim() || !weight.trim() || isNaN(parsedPrice) || parsedPrice <= 0) {
      alert('Please enter valid brand name, weight, and a positive price.');
      return;
    }
    onUpdatePreset(presetToEdit.id, { brandName: brandName.trim(), weight: weight.trim(), price: parsedPrice });
  };

  return (
    <div 
        className="fixed inset-0 bg-slate-900 bg-opacity-75 flex items-center justify-center p-4 z-50 transition-opacity duration-300"
        onClick={onClose}
    >
      <div 
        className="bg-white rounded-xl shadow-2xl p-6 w-full max-w-md space-y-5 transform transition-all duration-300 scale-95 opacity-0 animate-modalShow border border-slate-300"
        onClick={e => e.stopPropagation()} 
      >
        <div className="flex justify-between items-center">
            <h2 className="text-xl font-semibold text-slate-800 flex items-center">
                <CogIcon className="h-6 w-6 mr-2 text-blue-600" />
                Edit Preset: {presetToEdit.displayName}
            </h2>
            <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-full"
            >
            <XMarkIcon className="h-5 w-5" />
            </button>
        </div>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label htmlFor="editBrandName" className="block text-sm font-medium text-slate-600 mb-1">Brand Name</label>
            <input
              type="text"
              id="editBrandName"
              value={brandName}
              onChange={(e) => setBrandName(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
              required
              disabled={isLoading}
              autoFocus
            />
          </div>
          <div>
            <label htmlFor="editWeight" className="block text-sm font-medium text-slate-600 mb-1">Weight</label>
            <input
              type="text"
              id="editWeight"
              value={weight}
              onChange={(e) => setWeight(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
              placeholder="e.g., 14.2kg"
              required
              disabled={isLoading}
            />
          </div>
          <div>
            <label htmlFor="editPrice" className="block text-sm font-medium text-slate-600 mb-1">Price (৳)</label>
            <input
              type="number"
              id="editPrice"
              value={price}
              onChange={(e) => setPrice(e.target.value)}
              min="0.01"
              step="0.01"
              className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
              required
              disabled={isLoading}
            />
          </div>

          <div className="flex flex-col sm:flex-row gap-3 pt-3">
            <button
              type="button"
              onClick={onClose}
              disabled={isLoading}
              className="w-full sm:w-auto order-2 sm:order-1 bg-slate-200 hover:bg-slate-300 text-slate-700 font-medium py-2.5 px-4 rounded-md shadow hover:shadow-md hover:-translate-y-0.5 transform transition-all duration-150 ease-in-out disabled:opacity-60"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isLoading}
              className="w-full sm:flex-1 order-1 sm:order-2 flex items-center justify-center bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2.5 px-4 rounded-md shadow-md hover:shadow-lg hover:-translate-y-0.5 transform transition-all duration-150 ease-in-out disabled:opacity-60"
            >
              {isLoading ? 'Saving...' : 'Save Changes'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default PresetEditModal;