import React, { useState, FormEvent, useEffect } from 'react';
import { PresetButtonConfig, SaleEntry } from '../types';
import { PlusIcon, CalendarIcon, UserCircleIcon, MapPinIcon, PhoneIcon } from './Icons';

interface SaleModalProps {
  isOpen: boolean;
  onClose: () => void;
  preset: PresetButtonConfig | null;
  onConfirmSale: (saleData: Omit<SaleEntry, 'id' | 'totalAmount'>) => void;
  isLoading: boolean;
}

const SaleModal: React.FC<SaleModalProps> = ({ isOpen, onClose, preset, onConfirmSale, isLoading }) => {
  const [quantity, setQuantity] = useState<string>('1');
  const [buyerName, setBuyerName] = useState<string>('');
  const [buyerAddress, setBuyerAddress] = useState<string>('');
  const [buyerMobile, setBuyerMobile] = useState<string>('');
  const [saleDate, setSaleDate] = useState<string>(new Date().toISOString().split('T')[0]);

  useEffect(() => {
    if (isOpen) {
      setQuantity('1');
      setBuyerName('');
      setBuyerAddress('');
      setBuyerMobile('');
      setSaleDate(new Date().toISOString().split('T')[0]);
    }
  }, [isOpen, preset]);

  if (!isOpen || !preset) return null;

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    const qty = parseInt(quantity, 10);

    if (isNaN(qty) || qty <= 0) {
      alert('Please enter a valid quantity.');
      return;
    }

    onConfirmSale({
      cylinderDisplayName: preset.displayName,
      priceAtSale: preset.price,
      quantity: qty,
      saleDate,
      buyerName: buyerName.trim() === '' ? undefined : buyerName.trim(),
      buyerAddress: buyerAddress.trim() === '' ? undefined : buyerAddress.trim(),
      buyerMobile: buyerMobile.trim() === '' ? undefined : buyerMobile.trim(),
    });
  };

  return (
    <div 
        className="fixed inset-0 bg-slate-900 bg-opacity-75 flex items-center justify-center p-4 z-50 transition-opacity duration-300"
        onClick={onClose}
    >
      <div 
        className="bg-white rounded-xl shadow-2xl p-6 w-full max-w-lg space-y-5 transform transition-all duration-300 scale-95 opacity-0 animate-modalShow border border-slate-300"
        onClick={e => e.stopPropagation()}
      >
        <h2 className="text-2xl font-semibold text-slate-800">Log Sale for: <span className="text-blue-600">{preset.displayName}</span></h2>
        
        <div className="text-md text-slate-600">
          Price per unit: <span className="font-semibold">৳{preset.price.toFixed(2)}</span>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label htmlFor="quantity" className="block text-sm font-medium text-slate-600 mb-1">Quantity</label>
            <input
              type="number"
              id="quantity"
              value={quantity}
              onChange={(e) => setQuantity(e.target.value)}
              min="1"
              className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
              required
              disabled={isLoading}
              autoFocus
            />
          </div>
          
          <div className="border-t pt-4">
            <h3 className="text-lg font-medium text-slate-700 mb-2">Buyer Details (Optional)</h3>
            <div className="space-y-3">
                 <div>
                    <label htmlFor="buyerName" className="block text-sm font-medium text-slate-600 mb-1">Name</label>
                    <div className="relative">
                        <UserCircleIcon className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-slate-400" />
                        <input
                        type="text"
                        id="buyerName"
                        value={buyerName}
                        onChange={(e) => setBuyerName(e.target.value)}
                        className="w-full pl-10 pr-3 py-2 bg-slate-50 border border-slate-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
                        placeholder="e.g., Jane Doe"
                        disabled={isLoading}
                        />
                    </div>
                </div>
                <div>
                    <label htmlFor="buyerAddress" className="block text-sm font-medium text-slate-600 mb-1">Address</label>
                     <div className="relative">
                        <MapPinIcon className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-slate-400" />
                        <input
                        type="text"
                        id="buyerAddress"
                        value={buyerAddress}
                        onChange={(e) => setBuyerAddress(e.target.value)}
                        className="w-full pl-10 pr-3 py-2 bg-slate-50 border border-slate-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
                        placeholder="e.g., 123 Main St, Anytown"
                        disabled={isLoading}
                        />
                    </div>
                </div>
                <div>
                    <label htmlFor="buyerMobile" className="block text-sm font-medium text-slate-600 mb-1">Mobile Number</label>
                    <div className="relative">
                        <PhoneIcon className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-slate-400" />
                        <input
                        type="tel"
                        id="buyerMobile"
                        value={buyerMobile}
                        onChange={(e) => setBuyerMobile(e.target.value)}
                        className="w-full pl-10 pr-3 py-2 bg-slate-50 border border-slate-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
                        placeholder="e.g., 01xxxxxxxxx"
                        disabled={isLoading}
                        />
                    </div>
                </div>
            </div>
          </div>

          <div>
            <label htmlFor="saleDate" className="block text-sm font-medium text-slate-600 mb-1">Date of Sale</label>
            <div className="relative">
              <input
                type="date"
                id="saleDate"
                value={saleDate}
                onChange={(e) => setSaleDate(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 pr-10"
                disabled={isLoading}
                required
              />
              <CalendarIcon className="absolute right-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-slate-400 pointer-events-none" />
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-3 pt-3">
            <button
              type="button"
              onClick={onClose}
              disabled={isLoading}
              className="w-full sm:w-auto order-2 sm:order-1 bg-slate-200 hover:bg-slate-300 text-slate-700 font-medium py-2.5 px-4 rounded-md shadow hover:shadow-md hover:-translate-y-0.5 transform transition-all duration-150 ease-in-out disabled:opacity-60"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isLoading}
              className="w-full sm:flex-1 order-1 sm:order-2 flex items-center justify-center bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2.5 px-4 rounded-md shadow-md hover:shadow-lg hover:-translate-y-0.5 transform transition-all duration-150 ease-in-out disabled:opacity-60"
            >
              <PlusIcon className="h-5 w-5 mr-2" />
              {isLoading ? 'Saving Sale...' : 'Confirm Sale'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default SaleModal;