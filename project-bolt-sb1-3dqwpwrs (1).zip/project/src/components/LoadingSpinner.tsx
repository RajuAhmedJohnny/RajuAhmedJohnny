import React from 'react';

export const LoadingSpinner: React.FC<{text?: string}> = ({ text = "Processing..."}) => {
  return (
    <div className="flex items-center justify-center space-x-2">
      <div className="w-5 h-5 border-2 border-t-transparent border-blue-500 rounded-full animate-spin"></div>
      <span className="text-slate-700">{text}</span>
    </div>
  );
};