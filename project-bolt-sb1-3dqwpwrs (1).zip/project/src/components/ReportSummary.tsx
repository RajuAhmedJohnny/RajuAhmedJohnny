import React, { useState, useEffect } from 'react';
import { SalesReport, PresetButtonConfig } from '../types';
import { ReportIcon, CalendarIcon, ArrowPathIcon, FunnelIcon } from './Icons';

interface ReportSummaryProps {
  report: SalesReport | null;
  presets: PresetButtonConfig[];
  onApplyDateFilter: (startDate: string, endDate: string) => void;
  onResetDateFilter: () => void;
  initialReportStartDate?: string;
  initialReportEndDate?: string;
}

const ReportSummary: React.FC<ReportSummaryProps> = ({ 
    report, 
    presets, 
    onApplyDateFilter, 
    onResetDateFilter,
    initialReportStartDate,
    initialReportEndDate 
}) => {
  const [startDate, setStartDate] = useState<string>(initialReportStartDate || '');
  const [endDate, setEndDate] = useState<string>(initialReportEndDate || '');

  useEffect(() => {
    setStartDate(initialReportStartDate || '');
    setEndDate(initialReportEndDate || '');
  }, [initialReportStartDate, initialReportEndDate]);

  const handleFilterApply = () => {
    if (startDate && endDate) {
      if (new Date(startDate) > new Date(endDate)) {
        alert("Start date cannot be after end date.");
        return;
      }
      onApplyDateFilter(startDate, endDate);
    } else {
      alert("Please select both a start and end date for filtering.");
    }
  };

  const handleViewAllTime = () => {
    setStartDate('');
    setEndDate('');
    onResetDateFilter();
  };
  
  const getPeriodDisplay = (): string => {
    if (report?.periodStartDate && report?.periodEndDate) {
      const start = new Date(report.periodStartDate).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });
      const end = new Date(report.periodEndDate).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });
      return `Showing data from ${start} to ${end}`;
    }
    return "Showing all-time data";
  };

  if (!report || (presets.length === 0 && report.totalCylindersSold === 0 && !report.periodStartDate)) {
    return (
        <div className="p-6 bg-white shadow-xl rounded-xl mt-10 border border-slate-200">
            <h2 className="text-xl font-semibold text-slate-700 mb-3 flex items-center">
                <ReportIcon className="h-6 w-6 mr-2 text-blue-500" />
                Sales Summary
            </h2>
            {presets.length === 0 ? (
                <p className="text-slate-500">No sale presets defined. Please add presets to enable sales logging and reporting.</p>
            ) : (
                <p className="text-slate-500">No sales data yet to generate a report. Log some sales using the presets above!</p>
            )}
        </div>
    );
  }

  return (
    <div className="p-6 bg-white shadow-xl rounded-xl mt-10 border border-slate-200">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6">
        <h2 className="text-2xl font-semibold text-slate-700 flex items-center mb-3 sm:mb-0">
          <ReportIcon className="h-7 w-7 mr-3 text-blue-600" />
          Sales Summary
        </h2>
        <p className="text-sm text-slate-500">{getPeriodDisplay()}</p>
      </div>

      <div className="mb-8 p-4 bg-slate-50 rounded-lg border border-slate-200">
        <h3 className="text-md font-medium text-slate-600 mb-3 flex items-center">
          <CalendarIcon className="h-5 w-5 mr-2 text-slate-500" />
          Filter by Date Range:
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 items-end">
          <div>
            <label htmlFor="reportStartDate" className="block text-xs font-medium text-slate-500 mb-1">Start Date</label>
            <input 
              type="date" 
              id="reportStartDate"
              value={startDate}
              onChange={(e) => setStartDate(e.target.value)}
              className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
            />
          </div>
          <div>
            <label htmlFor="reportEndDate" className="block text-xs font-medium text-slate-500 mb-1">End Date</label>
            <input 
              type="date" 
              id="reportEndDate"
              value={endDate}
              onChange={(e) => setEndDate(e.target.value)}
              className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
            />
          </div>
        </div>
        <div className="mt-4 flex flex-col sm:flex-row gap-3">
          <button
            onClick={handleFilterApply}
            disabled={!startDate || !endDate}
            className="flex-1 flex items-center justify-center bg-blue-500 hover:bg-blue-600 text-white font-medium py-2 px-4 rounded-md shadow-sm hover:shadow-md disabled:opacity-50 transition-all"
          >
            <FunnelIcon className="h-4 w-4 mr-2" />
            Apply Filter
          </button>
          <button
            onClick={handleViewAllTime}
            className="flex-1 flex items-center justify-center bg-slate-200 hover:bg-slate-300 text-slate-700 font-medium py-2 px-4 rounded-md shadow-sm hover:shadow-md transition-all"
          >
            <ArrowPathIcon className="h-4 w-4 mr-2" />
            View All Time
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
        <div className="bg-blue-50 p-5 rounded-lg shadow-lg border border-blue-100">
          <p className="text-sm text-blue-700 font-medium uppercase tracking-wider">Total Revenue</p>
          <p className="text-3xl font-bold text-blue-600">৳{report.totalRevenue.toFixed(2)}</p>
        </div>
        <div className="bg-green-50 p-5 rounded-lg shadow-lg border border-green-100">
          <p className="text-sm text-green-700 font-medium uppercase tracking-wider">Total Cylinders Sold</p>
          <p className="text-3xl font-bold text-green-600">{report.totalCylindersSold}</p>
        </div>
      </div>

      <h3 className="text-xl font-semibold text-slate-600 mb-4">Breakdown by Cylinder Type:</h3>
      {presets.length > 0 ? (
        <div className="space-y-4">
          {presets.map(preset => {
            const typeData = report.salesByCylinderType[preset.displayName];
            if (!typeData || typeData.quantity === 0) {
              if (!report.periodStartDate) { 
                return (
                  <div key={preset.id} className="p-4 bg-slate-100 rounded-md shadow">
                    <p className="font-medium text-slate-700">{preset.displayName}</p>
                    <p className="text-sm text-slate-500">No sales recorded for this type{report.periodStartDate ? " in this period" : ""}.</p>
                  </div>
                );
              }
              return null;
            }
            return (
              <div key={preset.id} className="p-4 bg-slate-100 rounded-md shadow">
                <p className="font-medium text-slate-700">{preset.displayName}</p>
                <div className="flex flex-col sm:flex-row sm:justify-between text-sm mt-1">
                  <span className="text-slate-600">Quantity Sold: {typeData.quantity}</span>
                  <span className="text-slate-600 sm:ml-4">Revenue: ৳{typeData.revenue.toFixed(2)}</span>
                </div>
              </div>
            );
          })}
          {Object.entries(report.salesByCylinderType).map(([displayName, typeData]) => {
            if (!presets.find(p => p.displayName === displayName) && typeData.quantity > 0) {
              return (
                <div key={displayName} className="p-4 bg-yellow-50 border border-yellow-300 rounded-md shadow">
                  <p className="font-medium text-yellow-800">{displayName} (Preset Potentially Deleted)</p>
                  <div className="flex flex-col sm:flex-row sm:justify-between text-sm mt-1">
                    <span className="text-yellow-700">Quantity Sold: {typeData.quantity}</span>
                    <span className="text-yellow-700 sm:ml-4">Revenue: ৳{typeData.revenue.toFixed(2)}</span>
                  </div>
                </div>
              );
            }
            return null;
          })}
           {report.totalCylindersSold === 0 && presets.length > 0 && <p className="text-slate-500">No sales match the current filter criteria.</p>}
        </div>
      ) : (
        <p className="text-slate-500">No presets defined. Add cylinder presets to see a detailed breakdown.</p>
      )}
    </div>
  );
};

export default ReportSummary;