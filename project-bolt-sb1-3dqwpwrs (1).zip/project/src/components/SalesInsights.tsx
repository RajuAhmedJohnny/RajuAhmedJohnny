import React from 'react';
import { ChartBarIcon, LightBulbIcon } from './Icons';
import { LoadingSpinner } from './LoadingSpinner';

interface SalesInsightsProps {
  insights: string | null;
  onGenerateInsights: () => void;
  isLoading: boolean;
  error: string | null;
}

const SalesInsights: React.FC<SalesInsightsProps> = ({ insights, onGenerateInsights, isLoading, error }) => {
  return (
    <div className="p-6 bg-white shadow-xl rounded-xl mt-10 border border-slate-200">
      <h2 className="text-2xl font-semibold text-slate-700 mb-6 flex items-center">
        <LightBulbIcon className="h-7 w-7 mr-3 text-yellow-500" />
        AI Sales Insights
      </h2>

      <button
        onClick={onGenerateInsights}
        disabled={isLoading}
        className="flex items-center justify-center w-full sm:w-auto bg-yellow-500 hover:bg-yellow-600 text-white font-semibold py-2.5 px-6 rounded-lg shadow-md hover:shadow-lg hover:-translate-y-0.5 transform transition-all duration-150 ease-in-out disabled:opacity-70 disabled:cursor-not-allowed"
      >
        <ChartBarIcon className="h-5 w-5 mr-2" />
        {isLoading ? 'Generating Insights...' : 'Get AI Insights'}
      </button>

      {isLoading && (
        <div className="mt-6">
          <LoadingSpinner text="Analyzing sales data..." />
        </div>
      )}

      {error && !isLoading && (
        <div className="mt-6 p-4 bg-red-50 border border-red-300 text-red-700 rounded-md" role="alert">
          <p className="font-medium">Error:</p>
          <p>{error}</p>
        
        </div>
      )}

      {insights && !isLoading && !error && (
        <div className="mt-6 prose prose-slate max-w-none prose-p:my-2 prose-ul:my-2 prose-li:my-1 p-4 bg-yellow-50 border border-yellow-200 rounded-md">
          <h3 className="text-lg font-semibold text-yellow-800 mb-2">Here are your insights:</h3>
          {insights.split('\n').map((paragraph, index) => {
            if (paragraph.trim().startsWith('- ') || paragraph.trim().startsWith('* ') || paragraph.trim().startsWith('• ')) {
              return <p key={index} className="ml-4">{paragraph}</p>;
            }
            return <p key={index}>{paragraph || <br />}</p>;
        })}
        </div>
      )}
       {!insights && !isLoading && !error && (
         <p className="mt-6 text-slate-500">Click the button above to generate sales insights using AI.</p>
       )}
    </div>
  );
};

export default SalesInsights;