import React from 'react';
import { SaleEntry } from '../types';
import { CylinderIcon, TrashIcon, CalendarIcon, UserCircleIcon, MapPinIcon, PhoneIcon } from './Icons';

interface SaleItemProps {
  sale: SaleEntry;
  onDelete: (saleId: string) => void;
}

const SaleItem: React.FC<SaleItemProps> = ({ sale, onDelete }) => {
  const formattedDate = new Date(sale.saleDate).toLocaleDateString('en-GB', {
    day: '2-digit', month: 'short', year: 'numeric'
  });

  return (
    <div className="bg-white shadow-lg rounded-lg p-4 hover:shadow-xl hover:-translate-y-px transform transition-all duration-200 flex flex-col space-y-3 border border-slate-100">
      <div className="flex items-start justify-between">
        <div className="flex items-center space-x-3">
          <CylinderIcon className="h-10 w-10 text-blue-500 flex-shrink-0" />
          <div>
            <h3 className="text-lg font-semibold text-slate-700">{sale.cylinderDisplayName}</h3>
            <p className="text-xs text-slate-500">ID: {sale.id.slice(-6)}</p>
          </div>
        </div>
        <button
          onClick={() => onDelete(sale.id)}
          className="p-1.5 text-slate-400 hover:text-red-500 rounded-full hover:bg-red-100 transition-colors hover:scale-110 transform"
        >
          <TrashIcon className="h-5 w-5" />
        </button>
      </div>
      
      <div className="grid grid-cols-2 gap-x-4 gap-y-2 text-sm text-slate-600 border-t pt-3">
        <p><span className="font-medium">Quantity:</span> {sale.quantity}</p>
        <p><span className="font-medium">Price/Unit:</span> ৳{sale.priceAtSale.toFixed(2)}</p>
        <p className="col-span-2"><span className="font-medium">Total Sale:</span> <span className="font-bold text-blue-600 text-base">৳{sale.totalAmount.toFixed(2)}</span></p>
      </div>

      { (sale.buyerName || sale.buyerAddress || sale.buyerMobile) && (
        <div className="border-t pt-3 space-y-2 text-sm text-slate-600">
          <h4 className="font-medium text-slate-700">Buyer Details:</h4>
          {sale.buyerName && <p className="flex items-center"><UserCircleIcon className="h-4 w-4 mr-2 text-slate-400" /> {sale.buyerName}</p>}
          {sale.buyerAddress && <p className="flex items-center"><MapPinIcon className="h-4 w-4 mr-2 text-slate-400" /> {sale.buyerAddress}</p>}
          {sale.buyerMobile && <p className="flex items-center"><PhoneIcon className="h-4 w-4 mr-2 text-slate-400" /> {sale.buyerMobile}</p>}
        </div>
      )}

      <div className="flex items-center text-xs text-slate-500 pt-2 border-t border-slate-200 mt-auto">
        <CalendarIcon className="h-4 w-4 mr-1.5" />
        <span>Sale Date: {formattedDate}</span>
      </div>
    </div>
  );
};

export default SaleItem;