import React from 'react';
import { XMarkIcon, CogIcon, DocumentArrowDownIcon } from './Icons'; 
import { ReminderPeriod } from '../types';

interface SettingsDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  onDownloadReport: (period: ReminderPeriod | 'allTime') => void;
}

const SettingsDrawer: React.FC<SettingsDrawerProps> = ({ isOpen, onClose, onDownloadReport }) => {
  return (
    <>
      <div
        className={`fixed inset-0 bg-black bg-opacity-50 z-40 transition-opacity duration-300 ease-in-out ${
          isOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'
        }`}
        onClick={onClose}
      ></div>

      <div
        className={`fixed top-0 right-0 h-full w-full max-w-sm bg-slate-50 shadow-xl z-50 transform transition-transform duration-300 ease-in-out ${
          isOpen ? 'translate-x-0' : 'translate-x-full'
        }`}
      >
        <div className="flex flex-col h-full">
          <div className="flex items-center justify-between p-4 sm:p-6 border-b border-slate-200 bg-slate-100">
            <h2 className="text-xl font-semibold text-slate-700 flex items-center">
              <CogIcon className="h-6 w-6 mr-2 text-blue-600" />
              Settings
            </h2>
            <button
              onClick={onClose}
              className="p-2 text-slate-500 hover:text-slate-800 hover:bg-slate-200 rounded-full focus:outline-none focus:ring-2 focus:ring-slate-400"
            >
              <XMarkIcon className="h-6 w-6" />
            </button>
          </div>

          <div className="flex-grow p-4 sm:p-6 space-y-6 overflow-y-auto">
            <div className="p-4 border border-slate-200 rounded-lg bg-white">
              <h3 className="text-lg font-medium text-slate-700 mb-3 flex items-center">
                <DocumentArrowDownIcon className="h-5 w-5 mr-2 text-slate-500" /> Download Sales Data
              </h3>
              <div className="space-y-2">
                <button 
                  onClick={() => onDownloadReport('daily')}
                  className="w-full p-2.5 border border-blue-300 text-blue-700 hover:bg-blue-50 rounded-md text-sm transition-colors"
                >
                  Download Today's Sales PDF
                </button>
                <button 
                  onClick={() => onDownloadReport('weekly')}
                  className="w-full p-2.5 border border-blue-300 text-blue-700 hover:bg-blue-50 rounded-md text-sm transition-colors"
                >
                  Download Current Week's Sales PDF
                </button>
                <button 
                  onClick={() => onDownloadReport('monthly')}
                  className="w-full p-2.5 border border-blue-300 text-blue-700 hover:bg-blue-50 rounded-md text-sm transition-colors"
                >
                  Download Current Month's Sales PDF
                </button>
                 <button 
                  onClick={() => onDownloadReport('allTime')}
                  className="w-full p-2.5 border border-green-400 text-green-700 hover:bg-green-50 rounded-md text-sm transition-colors mt-2"
                >
                  Download All Sales Data PDF
                </button>
              </div>
            </div>
            
            <p className="text-xs text-center text-slate-400 pt-4">
              More settings can be added here in the future.
            </p>
          </div>
        </div>
      </div>
    </>
  );
};

export default SettingsDrawer;