import React from 'react';
import { SaleEntry } from '../types';
import SaleItem from './SaleItem';

interface SalesListProps {
  sales: SaleEntry[];
  onDeleteSale: (saleId: string) => void;
}

const SalesList: React.FC<SalesListProps> = ({ sales, onDeleteSale }) => {
  if (sales.length === 0) {
    return (
      <div className="text-center py-10 my-8 bg-white shadow-md rounded-lg">
        <p className="text-slate-500 text-lg">No sales recorded yet.</p>
        <p className="text-slate-400">Click on a preset button above to log a new sale!</p>
      </div>
    );
  }

  return (
    <div className="mt-8">
      <h2 className="text-2xl font-semibold text-slate-700 mb-6">Sales History</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {sales.map(sale => (
          <SaleItem key={sale.id} sale={sale} onDelete={onDeleteSale} />
        ))}
      </div>
    </div>
  );
};

export default SalesList;