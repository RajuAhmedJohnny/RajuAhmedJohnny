import React, { useState, FormEvent } from 'react';
import { PresetButtonConfig } from '../types';
import { PlusIcon, TrashIcon, TagIcon, CogIcon, CylinderIcon, PencilIcon } from './Icons';

interface PresetManagerProps {
  presets: PresetButtonConfig[];
  onAddPreset: (presetData: Omit<PresetButtonConfig, 'id' | 'displayName'>) => void;
  onDeletePreset: (presetId: string) => void;
  onEditPreset: (preset: PresetButtonConfig) => void;
  onPresetClick: (preset: PresetButtonConfig) => void;
  isLoading: boolean;
}

const PresetManager: React.FC<PresetManagerProps> = ({ 
    presets, 
    onAddPreset, 
    onDeletePreset, 
    onEditPreset, 
    onPresetClick, 
    isLoading 
}) => {
  const [brandName, setBrandName] = useState<string>('');
  const [weight, setWeight] = useState<string>('');
  const [price, setPrice] = useState<string>('');
  const [showForm, setShowForm] = useState<boolean>(false);

  const handleAddPresetSubmit = (e: FormEvent) => {
    e.preventDefault();
    const parsedPrice = parseFloat(price);
    if (!brandName.trim() || !weight.trim() || isNaN(parsedPrice) || parsedPrice <= 0) {
      alert('Please enter valid brand name, weight, and a positive price.');
      return;
    }
    onAddPreset({ brandName: brandName.trim(), weight: weight.trim(), price: parsedPrice });
    setBrandName('');
    setWeight('');
    setPrice('');
    setShowForm(false);
  };

  return (
    <div className="mb-10 p-6 bg-white shadow-2xl rounded-xl border border-slate-200">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-semibold text-slate-700 flex items-center">
          <CogIcon className="h-7 w-7 mr-3 text-blue-600" />
          Sale Presets
        </h2>
        <button
          onClick={() => setShowForm(!showForm)}
          className="flex items-center bg-blue-500 hover:bg-blue-600 text-white font-medium py-2 px-4 rounded-lg shadow-md hover:shadow-lg hover:-translate-y-0.5 transform transition-all duration-150 ease-in-out"
        >
          <PlusIcon className="h-5 w-5 mr-1.5" />
          {showForm ? 'Cancel Creation' : 'Add New Preset'}
        </button>
      </div>

      {showForm && (
        <form onSubmit={handleAddPresetSubmit} className="mb-8 p-6 bg-slate-50 rounded-lg border border-slate-200 space-y-4">
          <h3 className="text-lg font-medium text-slate-600 mb-3">Create New Sale Preset</h3>
          <div>
            <label htmlFor="brandName" className="block text-sm font-medium text-slate-600 mb-1">Brand Name</label>
            <input
              type="text"
              id="brandName"
              value={brandName}
              onChange={(e) => setBrandName(e.target.value)}
              className="w-full px-3 py-2 bg-white border border-slate-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
              placeholder="e.g., Indane, HP Gas"
              required
              disabled={isLoading}
            />
          </div>
          <div>
            <label htmlFor="weight" className="block text-sm font-medium text-slate-600 mb-1">Weight</label>
            <input
              type="text"
              id="weight"
              value={weight}
              onChange={(e) => setWeight(e.target.value)}
              className="w-full px-3 py-2 bg-white border border-slate-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
              placeholder="e.g., 14.2kg"
              required
              disabled={isLoading}
            />
          </div>
          <div>
            <label htmlFor="price" className="block text-sm font-medium text-slate-600 mb-1">Price (৳)</label>
            <input
              type="number"
              id="price"
              value={price}
              onChange={(e) => setPrice(e.target.value)}
              min="0.01"
              step="0.01"
              className="w-full px-3 py-2 bg-white border border-slate-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
              placeholder="e.g., 950.00"
              required
              disabled={isLoading}
            />
          </div>
          <button
            type="submit"
            disabled={isLoading}
            className="w-full flex items-center justify-center bg-green-500 hover:bg-green-600 text-white font-semibold py-2.5 px-4 rounded-md shadow-md hover:shadow-lg hover:-translate-y-0.5 transform transition-all duration-150 ease-in-out disabled:opacity-60"
          >
            <PlusIcon className="h-5 w-5 mr-2" />
            {isLoading ? 'Adding...' : 'Save Preset'}
          </button>
        </form>
      )}

      {presets.length === 0 && !showForm && (
        <p className="text-center text-slate-500 py-4">No presets created yet. Click "Add New Preset" to get started.</p>
      )}

      {presets.length > 0 && (
        <div>
            <h3 className="text-lg font-medium text-slate-600 mb-4">Click a Preset to Log Sale:</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {presets.map(preset => (
                <div key={preset.id} className="relative group flex flex-col">
                    <button
                        onClick={() => onPresetClick(preset)}
                        className="flex-grow w-full text-left p-4 bg-sky-500 hover:bg-sky-600 text-white rounded-lg shadow-lg hover:shadow-xl hover:-translate-y-0.5 transform transition-all duration-150 ease-in-out focus:outline-none focus:ring-2 focus:ring-sky-300 focus:ring-offset-2"
                    >
                        <div className="flex items-center mb-1">
                            <CylinderIcon className="h-6 w-6 mr-2 opacity-80" />
                            <span className="font-semibold text-base block truncate">{preset.displayName}</span>
                        </div>
                        <div className="flex items-center text-sm opacity-90">
                            <TagIcon className="h-4 w-4 mr-1.5" />
                            <span>৳{preset.price.toFixed(2)}</span>
                        </div>
                    </button>
                    <div className="absolute top-1 right-1 flex space-x-1 opacity-0 group-hover:opacity-100 focus-within:opacity-100 transition-opacity duration-150">
                        <button
                            onClick={() => onEditPreset(preset)}
                            className="p-1.5 bg-yellow-500 hover:bg-yellow-600 text-white rounded-full hover:scale-110 transform"
                            disabled={isLoading}
                        >
                            <PencilIcon className="h-3.5 w-3.5" />
                        </button>
                        <button
                            onClick={() => {
                                if(window.confirm(`Are you sure you want to delete the preset "${preset.displayName}"? This cannot be undone.`)) {
                                    onDeletePreset(preset.id);
                                }
                            }}
                            className="p-1.5 bg-red-500 hover:bg-red-700 text-white rounded-full hover:scale-110 transform"
                            disabled={isLoading}
                        >
                            <TrashIcon className="h-3.5 w-3.5" />
                        </button>
                    </div>
                </div>
            ))}
            </div>
        </div>
      )}
    </div>
  );
};

export default PresetManager;