import React from 'react';
import { ReminderPeriod } from '../types';
import { InformationCircleIcon, XMarkIcon } from './Icons';
import { LoadingSpinner } from './LoadingSpinner';

interface ReminderBannerProps {
  messages: {
    daily: string | null;
    weekly: string | null;
    monthly: string | null;
  };
  isLoading: {
    daily: boolean;
    weekly: boolean;
    monthly: boolean;
  };
  onDismiss: (period: ReminderPeriod) => void;
  onGoToDownloads: () => void;
  remindersDismissedThisSession: {
    daily: boolean;
    weekly: boolean;
    monthly: boolean;
  };
}

const ReminderBanner: React.FC<ReminderBannerProps> = ({ 
  messages, 
  isLoading, 
  onDismiss, 
  onGoToDownloads,
  remindersDismissedThisSession 
}) => {
  const activeReminderPeriods = (['daily', 'weekly', 'monthly'] as ReminderPeriod[]).filter(
    period => 
      !remindersDismissedThisSession[period] && 
      (messages[period] || isLoading[period])
  );

  if (activeReminderPeriods.length === 0) {
    return null;
  }

  return (
    <div className="bg-blue-50 border-b border-blue-200 p-3 shadow-sm sticky top-0 z-30">
      <div className="container mx-auto px-4">
        {activeReminderPeriods.map(period => (
          <div key={period} className="flex items-center justify-between py-2 border-b border-blue-100 last:border-b-0">
            <div className="flex items-center">
              <InformationCircleIcon className="h-6 w-6 text-blue-500 mr-2 flex-shrink-0" />
              {isLoading[period] && !messages[period] ? (
                <LoadingSpinner text={`Getting ${period} reminder...`} />
              ) : messages[period] ? (
                <p className="text-sm text-blue-700">{messages[period]}</p>
              ) : null }
            </div>
            <div className="flex items-center space-x-2 ml-2 flex-shrink-0">
              <button
                onClick={onGoToDownloads}
                className="text-xs bg-blue-500 hover:bg-blue-600 text-white font-medium py-1 px-2.5 rounded-md shadow-sm transition-colors"
              >
                Downloads
              </button>
              <button
                onClick={() => onDismiss(period)}
                className="p-1 text-blue-400 hover:text-blue-600 hover:bg-blue-100 rounded-full"
              >
                <XMarkIcon className="h-4 w-4" />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ReminderBanner;