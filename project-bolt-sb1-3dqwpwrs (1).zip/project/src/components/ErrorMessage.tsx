import React from 'react';
import { ExclamationTriangleIcon } from './Icons';

interface ErrorMessageProps {
  message: string;
}

export const ErrorMessage: React.FC<ErrorMessageProps> = ({ message }) => {
  return (
    <div className="mt-4 p-4 bg-red-100 border border-red-400 text-red-700 rounded-md flex items-center space-x-3" role="alert">
      <ExclamationTriangleIcon className="h-6 w-6 text-red-500 flex-shrink-0" />
      <p className="text-sm">{message}</p>
    </div>
  );
};