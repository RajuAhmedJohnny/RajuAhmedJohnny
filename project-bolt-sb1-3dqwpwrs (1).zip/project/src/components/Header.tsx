import React from 'react';
import { CylinderIcon, CogIcon } from './Icons';

interface HeaderProps {
  onToggleSettings: () => void;
}

export const Header: React.FC<HeaderProps> = ({ onToggleSettings }) => {
  return (
    <header className="bg-slate-800 shadow-lg py-2 sm:py-3 border-b border-slate-700">
      <div className="container mx-auto px-4 flex items-center justify-between">
        <div className="flex items-center">
          <CylinderIcon className="h-7 w-7 sm:h-8 sm:w-8 text-blue-400 mr-2 sm:mr-3" />
          <span 
            className="text-lg sm:text-2xl font-semibold text-slate-100"
            aria-label="CylinderFlow"
          >
            CylinderFlow
          </span>
        </div>
        
        <div className="flex items-center space-x-2 sm:space-x-3">
          <button
            onClick={onToggleSettings}
            className="p-1.5 sm:p-2 text-slate-300 hover:text-white hover:bg-slate-700 rounded-full focus:outline-none focus:ring-2 focus:ring-slate-500 transition-colors"
            aria-label="Open settings"
          >
            <CogIcon className="h-5 w-5 sm:h-6 sm:w-6" />
          </button>
        </div>
      </div>
    </header>
  );
};