import React, { useState, useRef, useEffect } from 'react';
import { ChatMessage } from '../types';
import { XMarkIcon, PaperAirplaneIcon, ChatBubbleLeftEllipsisIcon } from './Icons';
import { LoadingSpinner } from './LoadingSpinner';

interface ChatbotPanelProps {
  isOpen: boolean;
  onClose: () => void;
  messages: ChatMessage[];
  onSendMessage: (message: string) => void;
  isLoading: boolean;
  error: string | null;
}

const ChatbotPanel: React.FC<ChatbotPanelProps> = ({ isOpen, onClose, messages, onSendMessage, isLoading, error }) => {
  const [inputText, setInputText] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(scrollToBottom, [messages]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (inputText.trim()) {
      onSendMessage(inputText.trim());
      setInputText('');
    }
  };

  if (!isOpen) {
    return null;
  }

  return (
    <div className={`fixed bottom-0 right-0 sm:bottom-4 sm:right-4 h-[calc(100%-4rem)] sm:h-[500px] w-full sm:w-96 bg-white shadow-2xl rounded-t-lg sm:rounded-lg z-50 flex flex-col border border-slate-300 transform transition-transform duration-300 ease-in-out ${isOpen ? 'translate-y-0' : 'translate-y-full'}`}>
      <div className="flex items-center justify-between p-3 bg-slate-700 text-white rounded-t-lg sm:rounded-t-lg">
        <h3 className="font-semibold text-lg flex items-center">
          <ChatBubbleLeftEllipsisIcon className="h-6 w-6 mr-2" />
          AI Chatbot
        </h3>
        <button onClick={onClose} className="p-1.5 hover:bg-slate-600 rounded-full">
          <XMarkIcon className="h-5 w-5" />
        </button>
      </div>

      <div className="flex-grow p-4 space-y-3 overflow-y-auto bg-slate-50">
        {messages.map(msg => (
          <div key={msg.id} className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div
              className={`max-w-[80%] p-2.5 rounded-xl shadow ${
                msg.sender === 'user' 
                  ? 'bg-blue-500 text-white rounded-br-none' 
                  : 'bg-slate-200 text-slate-800 rounded-bl-none'
              }`}
            >
              <p className="text-sm whitespace-pre-wrap">{msg.text}</p>
              <p className={`text-xs mt-1 ${msg.sender === 'user' ? 'text-blue-100' : 'text-slate-500'} text-right`}>
                {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </p>
            </div>
          </div>
        ))}
        {isLoading && messages[messages.length-1]?.sender === 'user' && (
          <div className="flex justify-start">
            <div className="max-w-[80%] p-2.5 rounded-lg shadow bg-slate-200 text-slate-800 rounded-bl-none">
              <LoadingSpinner text="AI is thinking..." />
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {error && <p className="p-2 text-xs text-red-600 bg-red-100 border-t border-red-200">{error}</p>}

      <form onSubmit={handleSubmit} className="p-3 border-t border-slate-200 bg-slate-100">
        <div className="flex items-center space-x-2">
          <input
            type="text"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            placeholder="Ask something..."
            className="flex-grow p-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none shadow-sm text-sm"
            disabled={isLoading}
          />
          <button
            type="submit"
            disabled={isLoading || !inputText.trim()}
            className="p-2.5 bg-blue-500 hover:bg-blue-600 text-white rounded-lg shadow-md hover:shadow-lg disabled:opacity-50 disabled:cursor-not-allowed transition-all"
          >
            <PaperAirplaneIcon className="h-5 w-5" />
          </button>
        </div>
      </form>
    </div>
  );
};

export default ChatbotPanel;