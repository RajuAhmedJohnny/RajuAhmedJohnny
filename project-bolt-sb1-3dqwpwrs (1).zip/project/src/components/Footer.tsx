import React from 'react';
import { LifebuoyIcon, ChatBubbleLeftEllipsisIcon } from './Icons';

interface FooterProps {
  onToggleChatbot: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onToggleChatbot }) => {
  return (
    <footer className="py-6 text-center bg-slate-800 mt-auto">
      <div className="container mx-auto px-4 flex flex-col sm:flex-row justify-between items-center space-y-3 sm:space-y-0">
        <p className="text-sm text-slate-400">
          &copy; {new Date().getFullYear()} CylinderFlow. Track your sales.
        </p>
        <div className="flex items-center space-x-3 sm:space-x-4">
           <button
            onClick={onToggleChatbot}
            className="flex items-center text-sm text-slate-300 hover:text-blue-400 transition-colors"
            aria-label="Toggle AI Chatbot"
          >
            <ChatBubbleLeftEllipsisIcon className="h-5 w-5 mr-1" />
            AI Chatbot
          </button>
          <a
            href="mailto:support@example.com?subject=CylinderFlow Support Request"
            className="flex items-center text-sm text-slate-300 hover:text-blue-400 transition-colors"
            aria-label="Contact Customer Support"
          >
            <LifebuoyIcon className="h-5 w-5 mr-1" />
            Customer Support
          </a>
        </div>
      </div>
    </footer>
  );
};