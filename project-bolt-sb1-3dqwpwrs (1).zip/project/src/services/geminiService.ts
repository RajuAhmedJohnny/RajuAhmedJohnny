// Mock Gemini service for demonstration - replace with actual API integration
import { SalesReport, PresetButtonConfig, ReminderPeriod, ChatMessage } from '../types';

// Mock AI service - in production, you would use the actual Google Gemini API
let mockAiEnabled = false;

export interface Chat {
  sendMessage: (options: { message: string }) => Promise<{ text: string }>;
}

function formatSalesInsightPrompt(report: SalesReport, presets: PresetButtonConfig[]): string {
  let prompt = "Sales Analysis Summary:\n";
  prompt += `Total Revenue: ৳${report.totalRevenue.toFixed(2)}\n`;
  prompt += `Total Cylinders Sold: ${report.totalCylindersSold}\n\n`;
  
  if (presets.length > 0) {
    prompt += "Available Cylinder Types:\n";
    prompt += presets.map(p => `- ${p.displayName} (Price: ৳${p.price.toFixed(2)})`).join('\n');
  }
  
  return prompt;
}

export const getSalesInsights = async (report: SalesReport, presets: PresetButtonConfig[]): Promise<string> => {
  if (report.totalCylindersSold === 0 && report.totalRevenue === 0) {
    return "There's not enough sales data to generate insights yet. Keep logging your sales!";
  }

  // Mock insights - replace with actual Gemini API call
  const insights = [
    "Based on your sales data, here are some key insights:",
    `• You've sold ${report.totalCylindersSold} cylinders generating ৳${report.totalRevenue.toFixed(2)} in revenue`,
    "• Consider tracking which cylinder types sell best to optimize inventory",
    "• Regular data backup through PDF exports helps maintain accurate records"
  ];

  return insights.join('\n');
};

export const startNewChatSession = (): Chat | null => {
  // Mock chat session
  return {
    sendMessage: async ({ message }: { message: string }) => {
      // Mock response - replace with actual Gemini API call
      const responses = [
        "Hello! I'm here to help you with CylinderFlow. What would you like to know?",
        "I can help you understand your sales data and provide business insights.",
        "CylinderFlow helps you track gas cylinder sales efficiently. Is there something specific you'd like help with?",
        "Great question! I recommend keeping regular backups of your sales data and monitoring your best-selling cylinder types.",
        "Based on your question, I suggest focusing on your most profitable cylinder types and maintaining good customer records."
      ];
      
      return {
        text: responses[Math.floor(Math.random() * responses.length)]
      };
    }
  };
};

export const sendChatMessageToGemini = async (chat: Chat, message: string): Promise<string> => {
  if (!chat) {
    throw new Error("Chat session not initialized.");
  }

  try {
    const response = await chat.sendMessage({ message });
    return response.text;
  } catch (error: any) {
    throw new Error(`Failed to send message: ${error.message || 'Unknown error'}`);
  }
};

export const generateFriendlyReminder = async (period: ReminderPeriod): Promise<string> => {
  const reminders = {
    daily: "Time for your daily CylinderFlow data download! Keep those valuable sales records secure.",
    weekly: "Weekly reminder: Download your CylinderFlow sales data to maintain complete records.",
    monthly: "Monthly data backup time! Ensure your CylinderFlow sales records are safely stored."
  };

  return reminders[period] || `Don't forget to download your ${period} sales data for CylinderFlow.`;
};

export type { Chat };