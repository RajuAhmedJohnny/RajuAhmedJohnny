import { ReminderPeriod } from '../types';

const LAST_DAILY_DOWNLOAD_KEY = 'cylinderFlow_lastDailyDownloadDate';
const LAST_WEEKLY_DOWNLOAD_KEY = 'cylinderFlow_lastWeeklyDownloadKey';
const LAST_MONTHLY_DOWNLOAD_KEY = 'cylinderFlow_lastMonthlyDownloadKey';

const getCurrentDate = (): Date => {
  return new Date();
};

const getDayIdentifier = (date: Date): string => {
  const year = date.getFullYear();
  const month = (date.getMonth() + 1).toString().padStart(2, '0');
  const day = date.getDate().toString().padStart(2, '0');
  return `${year}-${month}-${day}`;
};

const getWeekIdentifier = (date: Date): string => {
  const d = new Date(Date.UTC(date.getFullYear(), date.getMonth(), date.getDate()));
  d.setUTCDate(d.getUTCDate() + 4 - (d.getUTCDay() || 7));
  const yearStart = new Date(Date.UTC(d.getUTCFullYear(), 0, 1));
  const weekNo = Math.ceil((((d.getTime() - yearStart.getTime()) / 86400000) + 1) / 7);
  return `${d.getUTCFullYear()}-W${weekNo.toString().padStart(2, '0')}`;
};

const getMonthIdentifier = (date: Date): string => {
  const year = date.getFullYear();
  const month = (date.getMonth() + 1).toString().padStart(2, '0');
  return `${year}-${month}`;
};

export const checkReminders = (): { daily: boolean; weekly: boolean; monthly: boolean } => {
  const today = getCurrentDate();
  
  const currentDailyKey = getDayIdentifier(today);
  const currentWeeklyKey = getWeekIdentifier(today);
  const currentMonthlyKey = getMonthIdentifier(today);

  const lastDaily = localStorage.getItem(LAST_DAILY_DOWNLOAD_KEY);
  const lastWeekly = localStorage.getItem(LAST_WEEKLY_DOWNLOAD_KEY);
  const lastMonthly = localStorage.getItem(LAST_MONTHLY_DOWNLOAD_KEY);

  return {
    daily: lastDaily !== currentDailyKey,
    weekly: lastWeekly !== currentWeeklyKey,
    monthly: lastMonthly !== currentMonthlyKey,
  };
};

export const updateLastDownloadTimestamp = (period: ReminderPeriod): void => {
  const today = getCurrentDate();
  try {
    if (period === 'daily') {
      localStorage.setItem(LAST_DAILY_DOWNLOAD_KEY, getDayIdentifier(today));
    } else if (period === 'weekly') {
      localStorage.setItem(LAST_WEEKLY_DOWNLOAD_KEY, getWeekIdentifier(today));
    } else if (period === 'monthly') {
      localStorage.setItem(LAST_MONTHLY_DOWNLOAD_KEY, getMonthIdentifier(today));
    }
  } catch (error) {
    console.error("Error updating last download timestamp in localStorage:", error);
  }
};