import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { SaleEntry, ReminderPeriod } from '../types';

const getStartOfWeek = (date: Date): Date => {
  const d = new Date(date);
  const day = d.getDay();
  const diff = d.getDate() - day;
  return new Date(d.setDate(diff));
};

const getEndOfWeek = (date: Date): Date => {
  const d = getStartOfWeek(date);
  return new Date(d.setDate(d.getDate() + 6));
};

const filterSalesByPeriod = (
  sales: SaleEntry[],
  period: ReminderPeriod | 'allTime',
  targetDate: Date = new Date()
): SaleEntry[] => {
  const target = new Date(targetDate.getFullYear(), targetDate.getMonth(), targetDate.getDate());

  switch (period) {
    case 'daily':
      return sales.filter(sale => {
        const saleDate = new Date(new Date(sale.saleDate).getFullYear(), new Date(sale.saleDate).getMonth(), new Date(sale.saleDate).getDate());
        return saleDate.getTime() === target.getTime();
      });
    case 'weekly':
      const startOfWeek = getStartOfWeek(target);
      const endOfWeek = getEndOfWeek(target);
      endOfWeek.setHours(23, 59, 59, 999);
      
      return sales.filter(sale => {
        const saleDate = new Date(sale.saleDate);
        return saleDate >= startOfWeek && saleDate <= endOfWeek;
      });
    case 'monthly':
      return sales.filter(sale => {
        const saleDate = new Date(sale.saleDate);
        return saleDate.getFullYear() === target.getFullYear() && saleDate.getMonth() === target.getMonth();
      });
    case 'allTime':
    default:
      return sales;
  }
};

const formatDate = (date: Date): string => {
    return date.toLocaleDateString('en-CA');
};

const generateSummary = (filteredSales: SaleEntry[]): { totalRevenue: number, totalCylindersSold: number } => {
  return filteredSales.reduce((acc, sale) => {
    acc.totalRevenue += sale.totalAmount;
    acc.totalCylindersSold += sale.quantity;
    return acc;
  }, { totalRevenue: 0, totalCylindersSold: 0 });
};

export const generateSalesReportPDF = (
  allSales: SaleEntry[],
  period: ReminderPeriod | 'allTime',
  targetDateInput?: Date
): void => {
  const targetDate = targetDateInput || new Date();
  const filteredSales = filterSalesByPeriod(allSales, period, targetDate);

  if (filteredSales.length === 0) {
    alert(`No sales data available for the selected ${period} period.`);
    return;
  }

  const doc = new jsPDF();
  const summary = generateSummary(filteredSales);

  let title = `CylinderFlow Sales Report - All Time`;
  let periodString = "All Time";

  if (period === 'daily') {
    periodString = `Date: ${formatDate(targetDate)}`;
    title = `CylinderFlow Daily Sales Report - ${formatDate(targetDate)}`;
  } else if (period === 'weekly') {
    const startOfWeek = getStartOfWeek(targetDate);
    const endOfWeek = getEndOfWeek(targetDate);
    periodString = `Week: ${formatDate(startOfWeek)} to ${formatDate(endOfWeek)}`;
    title = `CylinderFlow Weekly Sales Report`;
  } else if (period === 'monthly') {
    const monthYear = targetDate.toLocaleDateString('en-US', { year: 'numeric', month: 'long' });
    periodString = `Month: ${monthYear}`;
    title = `CylinderFlow Monthly Sales Report - ${monthYear}`;
  }
  
  doc.setFontSize(18);
  doc.text(title, 14, 22);
  
  doc.setFontSize(11);
  doc.setTextColor(100);
  doc.text(`Report Period: ${periodString}`, 14, 30);

  doc.setFontSize(12);
  doc.text(`Total Revenue: ৳${summary.totalRevenue.toFixed(2)}`, 14, 40);
  doc.text(`Total Cylinders Sold: ${summary.totalCylindersSold}`, 14, 46);

  const tableColumn = ["Date", "Cylinder Type", "Qty", "Price/Unit (৳)", "Total (৳)", "Buyer Name"];
  const tableRows: any[] = [];

  filteredSales.sort((a, b) => new Date(b.saleDate).getTime() - new Date(a.saleDate).getTime());

  filteredSales.forEach(sale => {
    const saleData = [
      formatDate(new Date(sale.saleDate)),
      sale.cylinderDisplayName,
      sale.quantity,
      sale.priceAtSale.toFixed(2),
      sale.totalAmount.toFixed(2),
      sale.buyerName || '-',
    ];
    tableRows.push(saleData);
  });

  autoTable(doc, {
    head: [tableColumn],
    body: tableRows,
    startY: 55,
    theme: 'striped',
    headStyles: { fillColor: [22, 160, 133] },
    styles: { fontSize: 9, cellPadding: 2 },
    columnStyles: {
        2: { halign: 'right' },
        3: { halign: 'right' },
        4: { halign: 'right' },
    }
  });

  const pageCount = (doc as any).internal.getNumberOfPages();
  for(let i = 1; i <= pageCount; i++) {
    doc.setPage(i);
    doc.setFontSize(9);
    doc.setTextColor(150);
    doc.text(`Page ${i} of ${pageCount}`, doc.internal.pageSize.width - 25, doc.internal.pageSize.height - 10);
    doc.text(`Generated: ${new Date().toLocaleString()}`, 14, doc.internal.pageSize.height - 10);
  }

  const filename = `CylinderFlow_Report_${period}_${formatDate(targetDate).replace(/-/g,'')}.pdf`;
  doc.save(filename);
};