import { neon } from '@neondatabase/serverless';

const DATABASE_URL = 'postgresql://neondb_owner:npg_B7AKle4oUaLx@ep-dry-bread-a5jg7aua-pooler.us-east-2.aws.neon.tech/neondb?sslmode=require';

const sql = neon(DATABASE_URL);

// Initialize database tables
export const initializeDatabase = async () => {
  try {
    // Create presets table
    await sql`
      CREATE TABLE IF NOT EXISTS presets (
        id TEXT PRIMARY KEY,
        brand_name TEXT NOT NULL,
        weight TEXT NOT NULL,
        price DECIMAL(10,2) NOT NULL,
        display_name TEXT NOT NULL UNIQUE,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `;

    // Create sales table
    await sql`
      CREATE TABLE IF NOT EXISTS sales (
        id TEXT PRIMARY KEY,
        cylinder_display_name TEXT NOT NULL,
        price_at_sale DECIMAL(10,2) NOT NULL,
        quantity INTEGER NOT NULL,
        total_amount DECIMAL(10,2) NOT NULL,
        sale_date DATE NOT NULL,
        buyer_name TEXT,
        buyer_address TEXT,
        buyer_mobile TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `;

    console.log('Database tables initialized successfully');
  } catch (error) {
    console.error('Error initializing database:', error);
    throw error;
  }
};

// Preset operations
export const getPresets = async () => {
  try {
    const result = await sql`
      SELECT id, brand_name, weight, price, display_name, created_at
      FROM presets
      ORDER BY created_at DESC
    `;
    
    return result.map(row => ({
      id: row.id,
      brandName: row.brand_name,
      weight: row.weight,
      price: parseFloat(row.price),
      displayName: row.display_name
    }));
  } catch (error) {
    console.error('Error fetching presets:', error);
    throw error;
  }
};

export const addPreset = async (preset: {
  id: string;
  brandName: string;
  weight: string;
  price: number;
  displayName: string;
}) => {
  try {
    await sql`
      INSERT INTO presets (id, brand_name, weight, price, display_name)
      VALUES (${preset.id}, ${preset.brandName}, ${preset.weight}, ${preset.price}, ${preset.displayName})
    `;
    return preset;
  } catch (error) {
    console.error('Error adding preset:', error);
    throw error;
  }
};

export const updatePreset = async (
  presetId: string,
  updatedData: {
    brandName: string;
    weight: string;
    price: number;
    displayName: string;
  }
) => {
  try {
    await sql`
      UPDATE presets 
      SET brand_name = ${updatedData.brandName},
          weight = ${updatedData.weight},
          price = ${updatedData.price},
          display_name = ${updatedData.displayName}
      WHERE id = ${presetId}
    `;
    return updatedData;
  } catch (error) {
    console.error('Error updating preset:', error);
    throw error;
  }
};

export const deletePreset = async (presetId: string) => {
  try {
    await sql`DELETE FROM presets WHERE id = ${presetId}`;
  } catch (error) {
    console.error('Error deleting preset:', error);
    throw error;
  }
};

// Sales operations
export const getSales = async () => {
  try {
    const result = await sql`
      SELECT id, cylinder_display_name, price_at_sale, quantity, total_amount,
             sale_date, buyer_name, buyer_address, buyer_mobile, created_at
      FROM sales
      ORDER BY created_at DESC
    `;
    
    return result.map(row => ({
      id: row.id,
      cylinderDisplayName: row.cylinder_display_name,
      priceAtSale: parseFloat(row.price_at_sale),
      quantity: row.quantity,
      totalAmount: parseFloat(row.total_amount),
      saleDate: row.sale_date,
      buyerName: row.buyer_name || undefined,
      buyerAddress: row.buyer_address || undefined,
      buyerMobile: row.buyer_mobile || undefined
    }));
  } catch (error) {
    console.error('Error fetching sales:', error);
    throw error;
  }
};

export const addSale = async (sale: {
  id: string;
  cylinderDisplayName: string;
  priceAtSale: number;
  quantity: number;
  totalAmount: number;
  saleDate: string;
  buyerName?: string;
  buyerAddress?: string;
  buyerMobile?: string;
}) => {
  try {
    await sql`
      INSERT INTO sales (
        id, cylinder_display_name, price_at_sale, quantity, total_amount,
        sale_date, buyer_name, buyer_address, buyer_mobile
      )
      VALUES (
        ${sale.id}, ${sale.cylinderDisplayName}, ${sale.priceAtSale}, 
        ${sale.quantity}, ${sale.totalAmount}, ${sale.saleDate},
        ${sale.buyerName || null}, ${sale.buyerAddress || null}, ${sale.buyerMobile || null}
      )
    `;
    return sale;
  } catch (error) {
    console.error('Error adding sale:', error);
    throw error;
  }
};

export const deleteSale = async (saleId: string) => {
  try {
    await sql`DELETE FROM sales WHERE id = ${saleId}`;
  } catch (error) {
    console.error('Error deleting sale:', error);
    throw error;
  }
};

export const getSalesInDateRange = async (startDate: string, endDate: string) => {
  try {
    const result = await sql`
      SELECT id, cylinder_display_name, price_at_sale, quantity, total_amount,
             sale_date, buyer_name, buyer_address, buyer_mobile, created_at
      FROM sales
      WHERE sale_date >= ${startDate} AND sale_date <= ${endDate}
      ORDER BY created_at DESC
    `;
    
    return result.map(row => ({
      id: row.id,
      cylinderDisplayName: row.cylinder_display_name,
      priceAtSale: parseFloat(row.price_at_sale),
      quantity: row.quantity,
      totalAmount: parseFloat(row.total_amount),
      saleDate: row.sale_date,
      buyerName: row.buyer_name || undefined,
      buyerAddress: row.buyer_address || undefined,
      buyerMobile: row.buyer_mobile || undefined
    }));
  } catch (error) {
    console.error('Error fetching sales in date range:', error);
    throw error;
  }
};