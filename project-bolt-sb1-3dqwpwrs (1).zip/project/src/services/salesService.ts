import { SaleEntry, SalesReport, PresetButtonConfig } from '../types';
import * as db from './database';

// --- Preset Button Functions ---

export const getPresetButtons = async (): Promise<PresetButtonConfig[]> => {
  try {
    return await db.getPresets();
  } catch (error) {
    console.error("Error retrieving preset buttons from database:", error);
    return [];
  }
};

export const addPresetButton = async (newPresetData: Omit<PresetButtonConfig, 'id' | 'displayName'>): Promise<PresetButtonConfig> => {
  try {
    const displayName = `${newPresetData.brandName} - ${newPresetData.weight}`;
    
    // Check if preset with same display name already exists
    const existingPresets = await db.getPresets();
    if (existingPresets.some(p => p.displayName === displayName)) {
      throw new Error(`A preset with the name "${displayName}" already exists.`);
    }

    const newPreset: PresetButtonConfig = {
      ...newPresetData,
      id: new Date().toISOString() + '-' + Math.random().toString(36).substr(2, 9),
      displayName: displayName,
    };

    await db.addPreset(newPreset);
    return newPreset;
  } catch (error: any) {
    console.error("Error adding preset button:", error);
    throw new Error(error.message || "Could not save preset.");
  }
};

export const updatePresetButton = async (
  presetId: string, 
  updatedData: Omit<PresetButtonConfig, 'id' | 'displayName'>
): Promise<PresetButtonConfig[]> => {
  try {
    const newDisplayName = `${updatedData.brandName} - ${updatedData.weight}`;
    
    // Check if the new display name conflicts with another existing preset
    const existingPresets = await db.getPresets();
    if (existingPresets.some(p => p.id !== presetId && p.displayName === newDisplayName)) {
      throw new Error(`Another preset with the name "${newDisplayName}" already exists.`);
    }

    await db.updatePreset(presetId, { ...updatedData, displayName: newDisplayName });
    return await db.getPresets();
  } catch (error: any) {
    console.error("Error updating preset button:", error);
    throw new Error(error.message || "Could not update preset.");
  }
};

export const deletePresetButton = async (presetId: string): Promise<PresetButtonConfig[]> => {
  try {
    await db.deletePreset(presetId);
    return await db.getPresets();
  } catch (error: any) {
    console.error("Error deleting preset button:", error);
    throw new Error(error.message || "Could not delete preset.");
  }
};

// --- Sales Functions ---

export const getSales = async (): Promise<SaleEntry[]> => {
  try {
    return await db.getSales();
  } catch (error) {
    console.error("Error retrieving sales from database:", error);
    return [];
  }
};

export const addSale = async (newSaleData: Omit<SaleEntry, 'id' | 'totalAmount'>): Promise<SaleEntry> => {
  try {
    const saleWithDetails: SaleEntry = {
      ...newSaleData,
      id: new Date().toISOString() + '-' + Math.random().toString(36).substr(2, 10), 
      totalAmount: newSaleData.quantity * newSaleData.priceAtSale,
    };

    await db.addSale(saleWithDetails);
    return saleWithDetails;
  } catch (error: any) {
    console.error("Error saving sale:", error);
    throw new Error(error.message || "Could not save sale.");
  }
};

export const deleteSale = async (saleId: string): Promise<SaleEntry[]> => {
  try {
    await db.deleteSale(saleId);
    return await db.getSales();
  } catch (error: any) {
    console.error("Error deleting sale:", error);
    throw new Error(error.message || "Could not delete sale.");
  }
};

export const generateSalesReport = async (
    allSales: SaleEntry[], 
    allPresets: PresetButtonConfig[],
    filterStartDate?: string, 
    filterEndDate?: string
): Promise<SalesReport> => {
  let filteredSales = allSales;

  if (filterStartDate && filterEndDate) {
    try {
      // Use database query for better performance with date filtering
      filteredSales = await db.getSalesInDateRange(filterStartDate, filterEndDate);
    } catch (error) {
      console.error("Error filtering sales by date range:", error);
      // Fallback to client-side filtering
      const startDate = new Date(filterStartDate);
      startDate.setHours(0, 0, 0, 0);

      const endDate = new Date(filterEndDate);
      endDate.setHours(23, 59, 59, 999);

      filteredSales = allSales.filter(sale => {
        const saleDate = new Date(sale.saleDate);
        return saleDate >= startDate && saleDate <= endDate;
      });
    }
  }

  const report: SalesReport = {
    totalRevenue: 0,
    totalCylindersSold: 0,
    salesByCylinderType: {},
    periodStartDate: filterStartDate,
    periodEndDate: filterEndDate,
  };

  // Initialize salesByCylinderType with all available preset display names
  allPresets.forEach(preset => {
    report.salesByCylinderType[preset.displayName] = { quantity: 0, revenue: 0 };
  });

  for (const sale of filteredSales) {
    report.totalRevenue += sale.totalAmount;
    report.totalCylindersSold += sale.quantity;
    
    if (!report.salesByCylinderType[sale.cylinderDisplayName]) {
        report.salesByCylinderType[sale.cylinderDisplayName] = { quantity: 0, revenue: 0 };
    }
    
    const typeSummary = report.salesByCylinderType[sale.cylinderDisplayName];
    typeSummary.quantity += sale.quantity;
    typeSummary.revenue += sale.totalAmount;
  }
  
  return report;
};