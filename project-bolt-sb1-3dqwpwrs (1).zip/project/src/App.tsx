import React, { useState, useEffect, useCallback } from 'react';
import { SaleEntry, SalesReport, PresetButtonConfig, ChatMessage, ReminderPeriod } from './types'; 
import * as salesService from './services/salesService';
import * as geminiService from './services/geminiService';
import * as pdfService from './services/pdfService';
import * as reminderService from './services/reminderService';
import * as database from './services/database';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import PresetManager from './components/PresetManager';
import SaleModal from './components/SaleModal';
import PresetEditModal from './components/PresetEditModal';
import SalesList from './components/SalesList';
import ReportSummary from './components/ReportSummary';
import SalesInsights from './components/SalesInsights';
import { ErrorMessage } from './components/ErrorMessage';
import SettingsDrawer from './components/SettingsDrawer';
import ChatbotPanel from './components/ChatbotPanel';
import { LoadingSpinner } from './components/LoadingSpinner';
import ReminderBanner from './components/ReminderBanner';

const App: React.FC = () => {
  const [allSales, setAllSales] = useState<SaleEntry[]>([]);
  const [displayedSales, setDisplayedSales] = useState<SaleEntry[]>([]);
  const [presets, setPresets] = useState<PresetButtonConfig[]>([]);
  const [report, setReport] = useState<SalesReport | null>(null);
  
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [isInitialized, setIsInitialized] = useState<boolean>(false);

  const [isSaleModalOpen, setIsSaleModalOpen] = useState<boolean>(false);
  const [currentPresetForSale, setCurrentPresetForSale] = useState<PresetButtonConfig | null>(null);

  const [isPresetEditModalOpen, setIsPresetEditModalOpen] = useState<boolean>(false);
  const [presetToEdit, setPresetToEdit] = useState<PresetButtonConfig | null>(null);

  const [geminiInsights, setGeminiInsights] = useState<string | null>(null);
  const [isGeminiLoading, setIsGeminiLoading] = useState<boolean>(false);
  const [geminiError, setGeminiError] = useState<string | null>(null);

  const [isSettingsDrawerOpen, setIsSettingsDrawerOpen] = useState<boolean>(false);

  const [isChatbotOpen, setIsChatbotOpen] = useState<boolean>(false);
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([]);
  const [isChatbotLoading, setIsChatbotLoading] = useState<boolean>(false);
  const [chatError, setChatError] = useState<string | null>(null);
  const [chatSession, setChatSession] = useState<geminiService.Chat | null>(null);

  const [reportStartDate, setReportStartDate] = useState<string | undefined>(undefined);
  const [reportEndDate, setReportEndDate] = useState<string | undefined>(undefined);

  const [activeRemindersFlags, setActiveRemindersFlags] = useState<{ daily: boolean, weekly: boolean, monthly: boolean }>({ daily: false, weekly: false, monthly: false });
  const [aiGeneratedReminderMessages, setAiGeneratedReminderMessages] = useState<{ daily: string | null, weekly: string | null, monthly: string | null }>({ daily: null, weekly: null, monthly: null });
  const [isLoadingAIReminders, setIsLoadingAIReminders] = useState<{ daily: boolean, weekly: boolean, monthly: boolean }>({ daily: false, weekly: false, monthly: false });
  const [remindersDismissedThisSession, setRemindersDismissedThisSession] = useState<{ daily: boolean, weekly: boolean, monthly: boolean }>({ daily: false, weekly: false, monthly: false });

  // Initialize database and load data
  const initializeApp = useCallback(async () => {
    setError(null);
    setIsLoading(true);
    
    try {
      // Initialize database tables
      await database.initializeDatabase();
      setIsInitialized(true);
      
      // Load data from database
      const loadedSales = await salesService.getSales();
      const loadedPresets = await salesService.getPresetButtons();
      setAllSales(loadedSales);
      
      // Default report to today
      const today = new Date();
      const todayStart = new Date(today.getFullYear(), today.getMonth(), today.getDate(), 0, 0, 0, 0);
      const todayEnd = new Date(today.getFullYear(), today.getMonth(), today.getDate(), 23, 59, 59, 999);
      const initialStartDate = reportStartDate === undefined ? todayStart.toISOString().split('T')[0] : reportStartDate;
      const initialEndDate = reportEndDate === undefined ? todayEnd.toISOString().split('T')[0] : reportEndDate;

      setReportStartDate(initialStartDate);
      setReportEndDate(initialEndDate);
      
      setPresets(loadedPresets);
      const initialReport = await salesService.generateSalesReport(loadedSales, loadedPresets, initialStartDate, initialEndDate);
      setReport(initialReport);

      let salesForDisplay = loadedSales;
      if (initialStartDate && initialEndDate) {
          const start = new Date(initialStartDate);
          start.setHours(0,0,0,0);
          const end = new Date(initialEndDate);
          end.setHours(23,59,59,999);
          salesForDisplay = loadedSales.filter(sale => {
              const saleDate = new Date(sale.saleDate);
              return saleDate >= start && saleDate <= end;
          });
      }
      setDisplayedSales(salesForDisplay);

      setActiveRemindersFlags(reminderService.checkReminders());

    } catch (e: any) {
      setError(`Failed to initialize application: ${e.message || 'Unknown error'}`);
      console.error('App initialization error:', e);
    } finally {
      setIsLoading(false);
    }
  }, [reportStartDate, reportEndDate]);

  useEffect(() => {
    initializeApp();
    
    // Initialize chat session
    if (!chatSession) {
      const newChat = geminiService.startNewChatSession();
      setChatSession(newChat);
      if (newChat) {
        setChatMessages([{ id: Date.now().toString(), text: "Hello! I'm your CylinderFlow AI assistant. How can I help you today?", sender: 'bot', timestamp: new Date() }]);
      } else {
        setChatError("Could not initialize AI Chatbot. API Key might be missing or invalid.");
      }
    }
  }, [initializeApp]);

  useEffect(() => {
    (async () => {
      const periods: ReminderPeriod[] = ['daily', 'weekly', 'monthly'];
      for (const period of periods) {
        if (activeRemindersFlags[period] && !aiGeneratedReminderMessages[period] && !remindersDismissedThisSession[period] && !isLoadingAIReminders[period]) {
          setIsLoadingAIReminders(prev => ({ ...prev, [period]: true }));
          try {
            const message = await geminiService.generateFriendlyReminder(period);
            setAiGeneratedReminderMessages(prev => ({ ...prev, [period]: message }));
          } catch (e) {
            console.error(`Error fetching AI reminder for ${period}:`, e);
            setAiGeneratedReminderMessages(prev => ({ ...prev, [period]: `Time for your ${period} sales data download! Keep your records safe.` }));
          } finally {
            setIsLoadingAIReminders(prev => ({ ...prev, [period]: false }));
          }
        }
      }
    })();
  }, [activeRemindersFlags, aiGeneratedReminderMessages, remindersDismissedThisSession, isLoadingAIReminders]);

  const refreshReportAndDisplayedSales = useCallback(async (updatedSales: SaleEntry[], currentPresets: PresetButtonConfig[], startDate?: string, endDate?: string) => {
    const newReport = await salesService.generateSalesReport(updatedSales, currentPresets, startDate, endDate);
    setReport(newReport);

    let salesForDisplay = updatedSales;
    if (startDate && endDate) {
        const start = new Date(startDate);
        start.setHours(0,0,0,0);
        const end = new Date(endDate);
        end.setHours(23,59,59,999);
        salesForDisplay = updatedSales.filter(sale => {
            const saleDate = new Date(sale.saleDate);
            return saleDate >= start && saleDate <= end;
        });
    }
    setDisplayedSales(salesForDisplay);
    setGeminiInsights(null); 
    setGeminiError(null);
  }, []);

  const handleAddPreset = useCallback(async (newPresetData: Omit<PresetButtonConfig, 'id' | 'displayName'>) => {
    setError(null);
    setIsLoading(true);
    try {
      const addedPreset = await salesService.addPresetButton(newPresetData);
      const updatedPresets = [...presets, addedPreset];
      setPresets(updatedPresets);
      await refreshReportAndDisplayedSales(allSales, updatedPresets, reportStartDate, reportEndDate);
    } catch (e: any) {
      setError(e.message || "An unknown error occurred while adding the preset.");
    } finally {
      setIsLoading(false);
    }
  }, [presets, allSales, refreshReportAndDisplayedSales, reportStartDate, reportEndDate]);

  const handleOpenEditPresetModal = useCallback((preset: PresetButtonConfig) => {
    setPresetToEdit(preset);
    setIsPresetEditModalOpen(true);
    setError(null);
  }, []);

  const handleCloseEditPresetModal = useCallback(() => {
    setIsPresetEditModalOpen(false);
    setPresetToEdit(null);
  }, []);

  const handleUpdatePreset = useCallback(async (presetId: string, updatedData: Omit<PresetButtonConfig, 'id' | 'displayName'>) => {
    setError(null);
    setIsLoading(true);
    try {
      const updatedPresets = await salesService.updatePresetButton(presetId, updatedData);
      setPresets(updatedPresets);
      await refreshReportAndDisplayedSales(allSales, updatedPresets, reportStartDate, reportEndDate);
      handleCloseEditPresetModal();
    } catch (e: any) {
      setError(e.message || "An unknown error occurred while updating the preset.");
    } finally {
      setIsLoading(false);
    }
  }, [allSales, refreshReportAndDisplayedSales, handleCloseEditPresetModal, reportStartDate, reportEndDate]);

  const handleDeletePreset = useCallback(async (presetId: string) => {
    setError(null);
    setIsLoading(true);
    try {
      const updatedPresets = await salesService.deletePresetButton(presetId);
      setPresets(updatedPresets);
      await refreshReportAndDisplayedSales(allSales, updatedPresets, reportStartDate, reportEndDate);
    } catch (e: any) {
      setError(e.message || "An unknown error occurred while deleting the preset.");
    } finally {
      setIsLoading(false);
    }
  }, [allSales, refreshReportAndDisplayedSales, reportStartDate, reportEndDate]);

  const handlePresetClickForSale = useCallback((preset: PresetButtonConfig) => {
    setCurrentPresetForSale(preset);
    setIsSaleModalOpen(true);
    setError(null);
  }, []);

  const handleCloseSaleModal = useCallback(() => {
    setIsSaleModalOpen(false);
    setCurrentPresetForSale(null);
  }, []);

  const handleConfirmSale = useCallback(async (saleDataFromModal: Omit<SaleEntry, 'id' | 'totalAmount'>) => {
    setError(null);
    setIsLoading(true);
    try {
      const addedSale = await salesService.addSale(saleDataFromModal);
      const updatedSales = [addedSale, ...allSales];
      setAllSales(updatedSales);
      await refreshReportAndDisplayedSales(updatedSales, presets, reportStartDate, reportEndDate);
      handleCloseSaleModal();
    } catch (e: any) {
      setError(e.message || "An unknown error occurred while adding the sale.");
    } finally {
      setIsLoading(false);
    }
  }, [allSales, presets, handleCloseSaleModal, refreshReportAndDisplayedSales, reportStartDate, reportEndDate]);
  
  const handleDeleteSale = useCallback(async (saleId: string) => {
    setError(null);
    try {
      const updatedSales = await salesService.deleteSale(saleId);
      setAllSales(updatedSales);
      await refreshReportAndDisplayedSales(updatedSales, presets, reportStartDate, reportEndDate);
    } catch (e: any) { 
      setError(e.message || "An unknown error occurred while deleting the sale.");
    }
  }, [presets, refreshReportAndDisplayedSales, reportStartDate, reportEndDate]);

  const handleGenerateSalesInsights = useCallback(async () => {
    if (!report) {
      setGeminiError("Sales report data is not available to generate insights.");
      return;
    }
    setIsGeminiLoading(true);
    setGeminiError(null);
    setGeminiInsights(null);
    try {
      const insights = await geminiService.getSalesInsights(report, presets);
      setGeminiInsights(insights);
    } catch (e: any) {
      setGeminiError(e.message || "An unexpected error occurred while fetching insights.");
    } finally {
      setIsGeminiLoading(false);
    }
  }, [report, presets]);

  const toggleSettingsDrawer = useCallback(() => setIsSettingsDrawerOpen(prev => !prev), []);
  const toggleChatbot = useCallback(() => setIsChatbotOpen(prev => !prev), []);

  const handleSendChatMessage = useCallback(async (messageText: string) => {
    if (!chatSession) {
        setChatError("Chat session not initialized. API Key might be missing or invalid.");
        return;
    }
    const newUserMessage: ChatMessage = {
      id: Date.now().toString(),
      text: messageText,
      sender: 'user',
      timestamp: new Date(),
    };
    setChatMessages(prev => [...prev, newUserMessage]);
    setIsChatbotLoading(true);
    setChatError(null);

    try {
      const botResponseText = await geminiService.sendChatMessageToGemini(chatSession, messageText);
      const newBotMessage: ChatMessage = {
        id: (Date.now() + 1).toString(),
        text: botResponseText,
        sender: 'bot',
        timestamp: new Date(),
      };
      setChatMessages(prev => [...prev, newBotMessage]);
    } catch (e: any) {
      setChatError(e.message || "Error communicating with AI Chatbot.");
      const errorBotMessage: ChatMessage = {
        id: (Date.now() + 1).toString(),
        text: "Sorry, I couldn't get a response. Please try again.",
        sender: 'bot',
        timestamp: new Date(),
      };
      setChatMessages(prev => [...prev, errorBotMessage]);
    } finally {
      setIsChatbotLoading(false);
    }
  }, [chatSession]);

  const handleDownloadReport = useCallback((period: ReminderPeriod | 'allTime') => {
    try {
      const targetDate = new Date();
      pdfService.generateSalesReportPDF(allSales, period, targetDate); 
      setError(null);
      if (period !== 'allTime') {
        reminderService.updateLastDownloadTimestamp(period);
        setAiGeneratedReminderMessages(prev => ({ ...prev, [period]: null }));
        setRemindersDismissedThisSession(prev => ({ ...prev, [period]: true }));
        setActiveRemindersFlags(reminderService.checkReminders()); 
      }
    } catch (e: any) {
      console.error("Error generating PDF report:", e);
      setError(`Failed to generate PDF report: ${e.message || 'Unknown error'}`);
    }
  }, [allSales]);

  const handleDismissReminder = useCallback((period: ReminderPeriod) => {
    setRemindersDismissedThisSession(prev => ({ ...prev, [period]: true }));
  }, []);

  const handleApplyDateFilter = useCallback(async (startDate: string, endDate: string) => {
    setReportStartDate(startDate);
    setReportEndDate(endDate);
    await refreshReportAndDisplayedSales(allSales, presets, startDate, endDate);
  }, [allSales, presets, refreshReportAndDisplayedSales]);

  const handleResetDateFilter = useCallback(async () => {
    const today = new Date();
    const todayStart = new Date(today.getFullYear(), today.getMonth(), today.getDate(), 0, 0, 0, 0);
    const todayEnd = new Date(today.getFullYear(), today.getMonth(), today.getDate(), 23, 59, 59, 999);
    const initialStartDate = todayStart.toISOString().split('T')[0];
    const initialEndDate = todayEnd.toISOString().split('T')[0];
    
    setReportStartDate(initialStartDate);
    setReportEndDate(initialEndDate);
    await refreshReportAndDisplayedSales(allSales, presets, initialStartDate, initialEndDate);
  }, [allSales, presets, refreshReportAndDisplayedSales]);

  if (!isInitialized || (isLoading && allSales.length === 0 && presets.length === 0)) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-100">
        <LoadingSpinner text="Connecting to database and initializing CylinderFlow..." />
      </div>
    );
  }

  return (
    <>
      <div className="min-h-screen flex flex-col bg-slate-100 text-slate-800">
        <Header onToggleSettings={toggleSettingsDrawer} />
         <ReminderBanner
          messages={aiGeneratedReminderMessages}
          isLoading={isLoadingAIReminders}
          onDismiss={handleDismissReminder}
          onGoToDownloads={toggleSettingsDrawer}
          remindersDismissedThisSession={remindersDismissedThisSession}
        />
        <main className="flex-grow container mx-auto px-4 py-8">
          {error && <ErrorMessage message={error} />}
          <PresetManager
            presets={presets}
            onAddPreset={handleAddPreset}
            onDeletePreset={handleDeletePreset}
            onEditPreset={handleOpenEditPresetModal}
            onPresetClick={handlePresetClickForSale}
            isLoading={isLoading && (allSales.length > 0 || presets.length > 0)}
          />
          <SalesList sales={displayedSales} onDeleteSale={handleDeleteSale} />
          <ReportSummary 
            report={report} 
            presets={presets}
            onApplyDateFilter={handleApplyDateFilter}
            onResetDateFilter={handleResetDateFilter}
            initialReportStartDate={reportStartDate}
            initialReportEndDate={reportEndDate}
          />
          <SalesInsights
            insights={geminiInsights}
            onGenerateInsights={handleGenerateSalesInsights}
            isLoading={isGeminiLoading}
            error={geminiError}
          />
        </main>
        <Footer onToggleChatbot={toggleChatbot} />
      </div>

      <SettingsDrawer 
        isOpen={isSettingsDrawerOpen} 
        onClose={toggleSettingsDrawer} 
        onDownloadReport={handleDownloadReport} 
      />
      
      {chatSession && (
        <ChatbotPanel
            isOpen={isChatbotOpen}
            onClose={toggleChatbot}
            messages={chatMessages}
            onSendMessage={handleSendChatMessage}
            isLoading={isChatbotLoading}
            error={chatError}
        />
      )}

      {currentPresetForSale && (
        <SaleModal
          isOpen={isSaleModalOpen}
          onClose={handleCloseSaleModal}
          preset={currentPresetForSale}
          onConfirmSale={handleConfirmSale}
          isLoading={isLoading && (allSales.length > 0 || presets.length > 0)}
        />
      )}

      {presetToEdit && (
        <PresetEditModal
          isOpen={isPresetEditModalOpen}
          onClose={handleCloseEditPresetModal}
          presetToEdit={presetToEdit}
          onUpdatePreset={handleUpdatePreset}
          isLoading={isLoading && (allSales.length > 0 || presets.length > 0)}
        />
      )}
    </>
  );
};

export default App;